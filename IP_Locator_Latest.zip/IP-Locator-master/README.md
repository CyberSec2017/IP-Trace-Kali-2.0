# IP-Locator was made by Spartanx retrieve informations about an ip adress or a hostname 
 This tool is scripted in perl as you can tell.:
 before opening the tool use this command  chmod +x ip-locator.pl it provides information from the following website 
http://ip-api.com/ 